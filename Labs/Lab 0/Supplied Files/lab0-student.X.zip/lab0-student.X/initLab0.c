/*
* File:   initLab0.c
* Author: 
*
* Created on December 27, 2014, 1:31 PM
*/

#include "p24fj64ga002.h"
#include "initLab0.h"

void initLEDs(){
    //TODO: Initialize the pin connected to the LEDs as outputs

    //TODO: Turn each LED OF
}

void initSW1(){
    //TODO: Initialize the pin connected to the switch as an input.
}


void initTimer1(){
    //TODO: Initialize the timer
}